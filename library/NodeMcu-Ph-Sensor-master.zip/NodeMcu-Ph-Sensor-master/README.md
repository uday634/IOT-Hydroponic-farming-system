# NodeMcu-Ph-Sensor
ESP code for Ph sensor and Displaying the reading on simple webpage
Connect the Sensor to the Analog pin of Arduino.

